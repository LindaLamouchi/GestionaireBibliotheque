﻿Imports System.Data.SqlClient
Imports System.Globalization

Public Class form4
    Dim connection As New SqlConnection("Server= (local); Database = TestDB; Integrated Security = true")

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If ((IsNumeric(Code.Text)) And (IsNumeric(idl.Text)) And (IsNumeric(ans.Text))) Then
            Dim mot As String
            mot = "libre"
            Dim cmd1 As New SqlCommand("select * from Livre , EtatLivre where code = '" & Code.Text & "' and nom='" & titre.Text & "'  and  auteur='" & auteur.Text & "' and categorie='" & categ.Text & "' and dte='" & ans.Text & "'", connection)
            Dim cmd3 As New SqlCommand("select idL from Table_login where idL= '" & idl.Text & "'", connection)
            Dim cmd2 As New SqlCommand("select * from Livre , EtatLivre where code =@codel and nom=@titree  and  auteur=@auteurr  and categorie=@catego and dte=@anss and EtatLivre.codeL=livre.codeLivre and EtatLivre.etat='" & mot & "'", connection)

            cmd2.Parameters.Add("@codel", SqlDbType.VarChar).Value = Code.Text
            cmd2.Parameters.Add("@titree", SqlDbType.VarChar).Value = titre.Text
            cmd2.Parameters.Add("@auteurr", SqlDbType.VarChar).Value = auteur.Text
            cmd2.Parameters.Add("@catego", SqlDbType.VarChar).Value = categ.Text
            cmd2.Parameters.Add("@anss", SqlDbType.VarChar).Value = ans.Text


            Dim adapter1 As New SqlDataAdapter(cmd1)
            Dim adapter2 As New SqlDataAdapter(cmd2)
            Dim adapter3 As New SqlDataAdapter(cmd3)
            Dim table1 As New DataTable()
            Dim table2 As New DataTable()
            Dim table3 As New DataTable()
            adapter3.Fill(table3)
            adapter1.Fill(table1)
            adapter2.Fill(table2)

            If table3.Rows.Count() <= 0 Then
                MsgBox("user n'existe pas ")
            ElseIf table1.Rows.Count() <= 0 Then
                MsgBox("verifier les donnéé entréé")

            ElseIf table2.Rows.Count() <= 0 Then
                MessageBox.Show("deja emprunté")

            Else

                MsgBox("l'emprunte de livre est valide")

                Dim updateQuery As String = "Update EtatLivre Set etat = 'occupeé'  WHERE codeL ='" & Code.Text & "'"
                ExecuteQuery(updateQuery)
                MessageBox.Show("Data Updated")

                Dim dateEm As String
                dateEm = dateEmp.Value
                Dim dateE As String = dateEm.Substring(0, 10)

                Dim dateRou As String
                dateRou = dateRetour.Value
                Dim dateR As String = dateRou.Substring(0, 10)

                Dim insertQuery As String = "INSERT INTO Emprunt (id,idL,dateEmp,dateRetour) VALUES('" & Code.Text & "','" & idl.Text & "','" & DateF(dateE) & "' ,'" & DateF(dateR) & "')"

                ExecuteQuery(insertQuery)

                MessageBox.Show("Data Inserted")
                Me.Hide()
            End If
        Else
            MsgBox("error")
        End If


    End Sub






    Public Sub ExecuteQuery(ByVal query As String)

        Dim command As New SqlCommand(query, connection)

        connection.Open()

        command.ExecuteNonQuery()

        connection.Close()

    End Sub



    Function DateF(ByVal s As String) As String
        Dim j As String
        Dim m As String
        Dim y As String
        j = s.Substring(0, 2)
        m = s.Substring(3, 2)
        y = s.Substring(6, 4)
        Dim d As String = y & "/" & m & "/" & j
        Return d
    End Function


    Private Sub connecter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles anul.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub form4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class


