﻿Imports System.Data.SqlClient
Public Class ModifLivre

    Dim conn As New SqlConnection("Data Source=hp-PC; Database = TestDB; Integrated Security = true")


    Sub int()
        textBox2.Text = ListeLivres.liste_livree.SelectedItem.ToString

    End Sub
    Private Sub ModifLivre_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        int()
    End Sub

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        If MsgBox("Etes vous certain de vouloir modifier ce livre ?", vbYesNo, "Confirmation") Then


            Try

                Dim insertQuery As String = "update Livre set auteur ='" + textBox3.Text + "' , nt='" + nte.Value.ToString + "' , genre='" + textBox7.Text + "' , maison='" + textBox4.Text + "'  "

                ExecuteQuery(insertQuery)
            Catch ex As Exception
                MsgBox("erreur : les donnees ne seront pas enregistres dans la base")

            End Try
            ListeLivres.Show()
            Me.Close()

        End If
    End Sub
    Public Sub ExecuteQuery(ByVal query As String)

        Dim command As New SqlCommand(query, conn)

        conn.Open()

        command.ExecuteNonQuery()

        conn.Close()

    End Sub

    Private Sub button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button3.Click
        ListeLivres.Show()
        Me.Close()
    End Sub


End Class