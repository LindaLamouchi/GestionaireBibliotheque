﻿Imports System.Data.SqlClient
Public Class Form5
    Dim connection As New SqlConnection("Server= (local); Database = TestDB; Integrated Security = true")
    Private Sub Form5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim cmd As New SqlCommand("select CodeLivre ,NomLivre from Livrel , Emprunt , Table_login where  Table_login.username = '" & Form1.nom.Text & "' and Table_login.idL= Emprunt.idL and Emprunt.id= livrel.CodeLivre ", connection)
        connection.Open()

        Dim dr As SqlDataReader = cmd.ExecuteReader()
        Do While (dr.Read())
            Dim arr As String() = New String(3) {}
            Dim itm As ListViewItem
            arr(0) = dr(0).ToString
            arr(1) = dr(1).ToString
            itm = New ListViewItem(arr)
            ListView1.Items.Add(itm)
        Loop
        connection.Close()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If (ListView1.SelectedItems.Count = 0) Then
            MsgBox("selectionner le livre a supprimer")
        Else
            Dim mot As String = "libre"
            Dim code As String = ListView1.SelectedItems(0).SubItems(0).Text.ToString
            Dim name As String = ListView1.SelectedItems(0).SubItems(1).Text.ToString

            ListView1.Items.RemoveAt(ListView1.SelectedIndices(0))

            Dim command As New SqlCommand("DELETE FROM Emprunt WHERE id='" & code & "' ", connection)
            Dim com As New SqlCommand("UPDATE EtatLivre SET etat = '" & mot & "' where CodeL='" & code & "'", connection)



            connection.Open()
            If command.ExecuteNonQuery() = 1 Then

                MessageBox.Show("User Deleted")

            Else

                MessageBox.Show("User Not Deleted")

            End If

            If com.ExecuteNonQuery() = 1 Then
                MessageBox.Show("Data Updated")

            Else
                MessageBox.Show("Data Not Updated")
            End If

            connection.Close()

        End If


    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Hide()
        Form2.Show()

    End Sub
End Class