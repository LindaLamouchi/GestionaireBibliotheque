﻿Imports System.Data.SqlClient
Public Class Form3



    Dim connection As New SqlConnection("Server=hp-PC; Database = TestDB; Integrated Security = true")



    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click


        If (Me.nom.Text = "") Then
            MessageBox.Show("verifier votre nom")

        ElseIf (Me.prenom.Text = "") Then
            MessageBox.Show("verifier votre prenom")

        ElseIf (verifID(Me.id.Text) = False) Then
            MsgBox("id existant")

        ElseIf (verifuser(Me.user.Text) = False) Then
            MessageBox.Show(" username deja existant")

        ElseIf (Me.pwd.Text = "") Then
            MessageBox.Show("entrer un mot de passe")

        ElseIf (verifmail(Me.mail.Text) = False) Then
            MessageBox.Show("verifier votre email")
        Else
            Dim dateNais As String
            dateNais = dateN.Value
            Dim dateNa As String = dateNais.Substring(0, 10)


            Dim insertQuery As String = "insert into Table_Login(idL,username,password,nom,prenom,dateNais,adresse,email) values('" & Me.id.Text & "' ,'" & Me.user.Text & "','" & Me.pwd.Text & "' ,'" & Me.nom.Text & "' ,'" & Me.prenom.Text & "' , '" & DateF(dateNa) & "', '" & Me.addresse.Text & "','" & Me.mail.Text & "')"
            ExecuteQuery(insertQuery)
            MessageBox.Show("Data Inserted")
            con.Visible = True



        End If
    End Sub

    Function verifID(ByVal id As String) As Boolean
        Dim strsql As String = "select idL from Table_login where ( idL) like '%" & id & "%'"
        Dim comd As New SqlCommand(strsql, connection)
        Dim adapter As New SqlDataAdapter(comd)
        Dim table As New DataTable()

        adapter.Fill(table)

        If ((table.Rows.Count() <= 0) And (IsNumeric(Me.id.Text))) Then

            Return True
        Else
            Return False
        End If

    End Function

    Function verifuser(ByVal usern As String) As Boolean
        Dim strsql As String = "select username from Table_login where ( username ) like '%" & usern & "%'"
        Dim comd As New SqlCommand(strsql, connection)
        Dim adapter As New SqlDataAdapter(comd)
        Dim table As New DataTable()

        adapter.Fill(table)

        If table.Rows.Count() <= 0 Then

            Return True
        Else
            Return False
        End If

    End Function


    Public Sub ExecuteQuery(ByVal query As String)

        Dim command As New SqlCommand(query, connection)

        connection.Open()
        command.ExecuteNonQuery()

        connection.Close()

    End Sub

    Function verifmail(ByVal email As String) As Boolean
        Dim emailExpr As New System.Text.RegularExpressions.Regex("^([\w]+)@([\w]+)\.([\w]+)$")
        Return emailExpr.IsMatch(email)
    End Function

    Function DateF(ByVal s As String) As String
        Dim j As String
        Dim m As String
        Dim y As String
        j = s.Substring(0, 2)
        m = s.Substring(3, 2)
        y = s.Substring(6, 4)
        Dim d As String = y & "/" & m & "/" & j
        Return d
    End Function


    Private Sub connecter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles annuler.Click
        Me.Close()
        nom.Text = ""
        prenom.Text = ""
        pwd.Text = ""
        id.Text = ""
        user.Text = ""
        mail.Text = ""
        addresse.Text = ""
        Form1.Show()

    End Sub



    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles con.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class