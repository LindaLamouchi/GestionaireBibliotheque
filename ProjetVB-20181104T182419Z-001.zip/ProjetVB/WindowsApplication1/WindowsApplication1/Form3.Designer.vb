﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.Button2 = New System.Windows.Forms.Button()
        Me.annuler = New System.Windows.Forms.Button()
        Me.prenom = New System.Windows.Forms.TextBox()
        Me.mail = New System.Windows.Forms.TextBox()
        Me.pwd = New System.Windows.Forms.TextBox()
        Me.id = New System.Windows.Forms.TextBox()
        Me.user = New System.Windows.Forms.TextBox()
        Me.nom = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.con = New System.Windows.Forms.Button()
        Me.dateN = New System.Windows.Forms.DateTimePicker()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.addresse = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Wheat
        Me.Button2.Font = New System.Drawing.Font("Palatino Linotype", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(477, 250)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(176, 41)
        Me.Button2.TabIndex = 45
        Me.Button2.Text = "Done"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'annuler
        '
        Me.annuler.BackColor = System.Drawing.Color.Wheat
        Me.annuler.Font = New System.Drawing.Font("Palatino Linotype", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.annuler.Location = New System.Drawing.Point(477, 349)
        Me.annuler.Name = "annuler"
        Me.annuler.Size = New System.Drawing.Size(176, 43)
        Me.annuler.TabIndex = 44
        Me.annuler.Text = "Annuler"
        Me.annuler.UseVisualStyleBackColor = False
        '
        'prenom
        '
        Me.prenom.Location = New System.Drawing.Point(192, 100)
        Me.prenom.Multiline = True
        Me.prenom.Name = "prenom"
        Me.prenom.Size = New System.Drawing.Size(173, 37)
        Me.prenom.TabIndex = 43
        '
        'mail
        '
        Me.mail.Location = New System.Drawing.Point(192, 408)
        Me.mail.Multiline = True
        Me.mail.Name = "mail"
        Me.mail.Size = New System.Drawing.Size(173, 38)
        Me.mail.TabIndex = 42
        '
        'pwd
        '
        Me.pwd.Location = New System.Drawing.Point(192, 327)
        Me.pwd.Multiline = True
        Me.pwd.Name = "pwd"
        Me.pwd.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.pwd.Size = New System.Drawing.Size(173, 41)
        Me.pwd.TabIndex = 41
        '
        'id
        '
        Me.id.Location = New System.Drawing.Point(192, 176)
        Me.id.Multiline = True
        Me.id.Name = "id"
        Me.id.Size = New System.Drawing.Size(173, 37)
        Me.id.TabIndex = 40
        '
        'user
        '
        Me.user.Location = New System.Drawing.Point(192, 254)
        Me.user.Multiline = True
        Me.user.Name = "user"
        Me.user.Size = New System.Drawing.Size(173, 37)
        Me.user.TabIndex = 39
        '
        'nom
        '
        Me.nom.Location = New System.Drawing.Point(192, 29)
        Me.nom.Multiline = True
        Me.nom.Name = "nom"
        Me.nom.Size = New System.Drawing.Size(173, 37)
        Me.nom.TabIndex = 38
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Wheat
        Me.Label3.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(27, 254)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(106, 37)
        Me.Label3.TabIndex = 37
        Me.Label3.Text = "Username *"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Wheat
        Me.Label2.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(27, 327)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(106, 41)
        Me.Label2.TabIndex = 36
        Me.Label2.Text = "Password *"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Wheat
        Me.Label1.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(26, 408)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(106, 37)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "email *"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Wheat
        Me.Label6.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(26, 30)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(107, 36)
        Me.Label6.TabIndex = 34
        Me.Label6.Text = "Nom *"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Wheat
        Me.Label5.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(27, 107)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(106, 30)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "Prenom *"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Wheat
        Me.Label4.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(27, 180)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(106, 33)
        Me.Label4.TabIndex = 32
        Me.Label4.Text = "Id *"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'con
        '
        Me.con.BackColor = System.Drawing.Color.Black
        Me.con.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.con.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.con.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.con.Location = New System.Drawing.Point(629, 581)
        Me.con.Name = "con"
        Me.con.Size = New System.Drawing.Size(158, 36)
        Me.con.TabIndex = 51
        Me.con.Text = "connecter >>"
        Me.con.UseVisualStyleBackColor = False
        Me.con.Visible = False
        '
        'dateN
        '
        Me.dateN.Location = New System.Drawing.Point(192, 595)
        Me.dateN.Name = "dateN"
        Me.dateN.Size = New System.Drawing.Size(165, 20)
        Me.dateN.TabIndex = 50
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label10.Location = New System.Drawing.Point(623, 620)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(164, 18)
        Me.Label10.TabIndex = 49
        Me.Label10.Text = "* : champ obligatoire"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Wheat
        Me.Label8.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(23, 578)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(109, 37)
        Me.Label8.TabIndex = 48
        Me.Label8.Text = "BirthDay"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'addresse
        '
        Me.addresse.Location = New System.Drawing.Point(195, 493)
        Me.addresse.Multiline = True
        Me.addresse.Name = "addresse"
        Me.addresse.Size = New System.Drawing.Size(173, 43)
        Me.addresse.TabIndex = 47
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Wheat
        Me.Label7.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(23, 498)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(110, 38)
        Me.Label7.TabIndex = 46
        Me.Label7.Text = "addresse"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(799, 647)
        Me.Controls.Add(Me.con)
        Me.Controls.Add(Me.dateN)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.addresse)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.annuler)
        Me.Controls.Add(Me.prenom)
        Me.Controls.Add(Me.mail)
        Me.Controls.Add(Me.pwd)
        Me.Controls.Add(Me.id)
        Me.Controls.Add(Me.user)
        Me.Controls.Add(Me.nom)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form3"
        Me.Text = "S'inscrire"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents annuler As System.Windows.Forms.Button
    Friend WithEvents prenom As System.Windows.Forms.TextBox
    Friend WithEvents mail As System.Windows.Forms.TextBox
    Friend WithEvents pwd As System.Windows.Forms.TextBox
    Friend WithEvents id As System.Windows.Forms.TextBox
    Friend WithEvents user As System.Windows.Forms.TextBox
    Friend WithEvents nom As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents con As System.Windows.Forms.Button
    Friend WithEvents dateN As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents addresse As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
End Class
