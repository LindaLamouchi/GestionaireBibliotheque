﻿Imports System.Data.SqlClient
Public Class ListeLivres
    Dim conn As New SqlConnection("Data Source=hp-PC; Database = TestDB; Integrated Security = true")

    Public Sub ExecuteQuery(ByVal query As String)

        Dim command As New SqlCommand(query, conn)

        conn.Open()

        command.ExecuteNonQuery()

        conn.Close()

    End Sub
    Public Sub Execute(ByVal query As String)

        Dim command As New SqlCommand(query, conn)

        conn.Open()
        Dim dr As SqlDataReader = command.ExecuteReader()
        If dr.Read() Then
            liste_livree.Items.Clear()
            liste_livree.Items.Add(dr(2).ToString())

        End If
       
        conn.Close()
        command.Dispose()

    End Sub
    Private Sub rcherche_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rcherche.Click
        If Not (Me.titre.Text = "") Then
            'lecture unitaire nom=>cle primaire
            Try

                Dim insertQuery As String = "select * from Livre where nom = '" & Me.titre.Text & "' "
                Execute(insertQuery)

            Catch ex As Exception
                MsgBox("err requete")

            End Try

        End If
        
    End Sub

    Private Sub createe_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles createe.Click
        AjoutEditionLivre.Show()
        Me.Hide()
    End Sub

    Private Sub supprime_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles supprime.Click
        If MsgBox("Etes vous certain de vouloir supprimer ce livre ?", vbYesNo, "Confirmation") Then
            'On le retire de la liste


            Try

                Dim insertQuery As String = "delete Livre where nom = '" & Me.titre.Text & "' "

                Execute(insertQuery)
            Catch ex As Exception
                MsgBox("annulation de suppression")

            End Try
        End If
    End Sub

    Private Sub effacee_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles effacee.Click
        Me.titre.Text = ""
        Me.auteur.Text = ""
       
    End Sub

    Private Sub modif_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles modif.Click

        ModifLivre.Show()
        Me.Hide()

    End Sub

    Private Sub QuitterToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QuitterToolStripMenuItem.Click
        Me.Close()

    End Sub

    Private Sub liste_livree_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles liste_livree.SelectedIndexChanged
        Dim query As String = "select * from Livre where nom ='" + liste_livree.SelectedItem.ToString + "'"

        Dim command As New SqlCommand(query, conn)

        conn.Open()
        Dim dr As SqlDataReader = command.ExecuteReader()
        If dr.Read() Then
            dte.Text = dr(6).ToString()
            atr.Text = dr(0).ToString
            gnre.Text = dr(3).ToString
            titr.Text = dr(2).ToString
            gr.Text = dr(3).ToString
            edit.Text = dr(8).ToString
            collect.Text = dr(7).ToString
            thoughts.Text = dr(1).ToString
        End If

        conn.Close()
        command.Dispose()

    End Sub

    Private Sub HomeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HomeToolStripMenuItem.Click
        Admin_Interf.Show()
        Me.Hide()

    End Sub


End Class