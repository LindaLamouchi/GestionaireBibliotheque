﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AjoutEditionLivre
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AjoutEditionLivre))
        Me.BT_SAVE = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.nte = New System.Windows.Forms.NumericUpDown()
        Me.Mais = New System.Windows.Forms.TextBox()
        Me.gnr2 = New System.Windows.Forms.ComboBox()
        Me.gnre1 = New System.Windows.Forms.ComboBox()
        Me.auteurr = New System.Windows.Forms.ComboBox()
        Me.dt_srt = New System.Windows.Forms.DateTimePicker()
        Me.nom = New System.Windows.Forms.TextBox()
        Me.label15 = New System.Windows.Forms.Label()
        Me.avis = New System.Windows.Forms.TextBox()
        Me.coll = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.collection = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.IMG_AFFICHE = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LivresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdherantToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QuitterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HomeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.nte, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.IMG_AFFICHE, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'BT_SAVE
        '
        Me.BT_SAVE.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BT_SAVE.Location = New System.Drawing.Point(468, 520)
        Me.BT_SAVE.Name = "BT_SAVE"
        Me.BT_SAVE.Size = New System.Drawing.Size(256, 23)
        Me.BT_SAVE.TabIndex = 70
        Me.BT_SAVE.Text = "Enregistrer et fermer"
        Me.BT_SAVE.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(390, 513)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(24, 13)
        Me.Label1.TabIndex = 69
        Me.Label1.Text = "/20"
        '
        'nte
        '
        Me.nte.Location = New System.Drawing.Point(234, 513)
        Me.nte.Maximum = New Decimal(New Integer() {20, 0, 0, 0})
        Me.nte.Name = "nte"
        Me.nte.Size = New System.Drawing.Size(160, 20)
        Me.nte.TabIndex = 68
        Me.nte.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Mais
        '
        Me.Mais.Location = New System.Drawing.Point(423, 199)
        Me.Mais.Multiline = True
        Me.Mais.Name = "Mais"
        Me.Mais.Size = New System.Drawing.Size(282, 53)
        Me.Mais.TabIndex = 67
        '
        'gnr2
        '
        Me.gnr2.FormattingEnabled = True
        Me.gnr2.Location = New System.Drawing.Point(423, 170)
        Me.gnr2.Name = "gnr2"
        Me.gnr2.Size = New System.Drawing.Size(282, 21)
        Me.gnr2.TabIndex = 66
        '
        'gnre1
        '
        Me.gnre1.FormattingEnabled = True
        Me.gnre1.Location = New System.Drawing.Point(423, 143)
        Me.gnre1.Name = "gnre1"
        Me.gnre1.Size = New System.Drawing.Size(282, 21)
        Me.gnre1.TabIndex = 65
        '
        'auteurr
        '
        Me.auteurr.FormattingEnabled = True
        Me.auteurr.Location = New System.Drawing.Point(423, 115)
        Me.auteurr.Name = "auteurr"
        Me.auteurr.Size = New System.Drawing.Size(282, 21)
        Me.auteurr.TabIndex = 64
        '
        'dt_srt
        '
        Me.dt_srt.Location = New System.Drawing.Point(416, 88)
        Me.dt_srt.Name = "dt_srt"
        Me.dt_srt.Size = New System.Drawing.Size(289, 20)
        Me.dt_srt.TabIndex = 63
        '
        'nom
        '
        Me.nom.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nom.Location = New System.Drawing.Point(343, 46)
        Me.nom.Name = "nom"
        Me.nom.Size = New System.Drawing.Size(362, 26)
        Me.nom.TabIndex = 62
        '
        'label15
        '
        Me.label15.AutoSize = True
        Me.label15.Location = New System.Drawing.Point(129, 489)
        Me.label15.Name = "label15"
        Me.label15.Size = New System.Drawing.Size(93, 13)
        Me.label15.TabIndex = 61
        Me.label15.Text = "Note personnelle :"
        '
        'avis
        '
        Me.avis.Location = New System.Drawing.Point(127, 386)
        Me.avis.Multiline = True
        Me.avis.Name = "avis"
        Me.avis.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.avis.Size = New System.Drawing.Size(578, 63)
        Me.avis.TabIndex = 60
        '
        'coll
        '
        Me.coll.Location = New System.Drawing.Point(127, 283)
        Me.coll.Multiline = True
        Me.coll.Name = "coll"
        Me.coll.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.coll.Size = New System.Drawing.Size(578, 84)
        Me.coll.TabIndex = 59
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(67, 370)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(82, 13)
        Me.Label16.TabIndex = 58
        Me.Label16.Text = "Avis personnel :"
        '
        'collection
        '
        Me.collection.AutoSize = True
        Me.collection.Location = New System.Drawing.Point(67, 267)
        Me.collection.Name = "collection"
        Me.collection.Size = New System.Drawing.Size(128, 13)
        Me.collection.TabIndex = 57
        Me.collection.Text = "Dans la meme collection :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(258, 202)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(89, 13)
        Me.Label13.TabIndex = 56
        Me.Label13.Text = "Maison d'edition :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(258, 178)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(51, 13)
        Me.Label12.TabIndex = 55
        Me.Label12.Text = "Genre 2 :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(258, 146)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(51, 13)
        Me.Label11.TabIndex = 54
        Me.Label11.Text = "Genre 1 :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(258, 123)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(50, 13)
        Me.Label10.TabIndex = 53
        Me.Label10.Text = "Auteur   :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(258, 95)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(79, 13)
        Me.Label8.TabIndex = 52
        Me.Label8.Text = "Date de sortie :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(337, 91)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(0, 13)
        Me.Label6.TabIndex = 51
        '
        'IMG_AFFICHE
        '
        Me.IMG_AFFICHE.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.IMG_AFFICHE.Location = New System.Drawing.Point(70, 46)
        Me.IMG_AFFICHE.Name = "IMG_AFFICHE"
        Me.IMG_AFFICHE.Size = New System.Drawing.Size(182, 218)
        Me.IMG_AFFICHE.TabIndex = 50
        Me.IMG_AFFICHE.TabStop = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HomeToolStripMenuItem, Me.EditToolStripMenuItem, Me.QuitterToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(773, 24)
        Me.MenuStrip1.TabIndex = 71
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LivresToolStripMenuItem, Me.AdherantToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(49, 20)
        Me.EditToolStripMenuItem.Text = "Editer"
        '
        'LivresToolStripMenuItem
        '
        Me.LivresToolStripMenuItem.Name = "LivresToolStripMenuItem"
        Me.LivresToolStripMenuItem.Size = New System.Drawing.Size(123, 22)
        Me.LivresToolStripMenuItem.Text = " Livres"
        '
        'AdherantToolStripMenuItem
        '
        Me.AdherantToolStripMenuItem.Name = "AdherantToolStripMenuItem"
        Me.AdherantToolStripMenuItem.Size = New System.Drawing.Size(123, 22)
        Me.AdherantToolStripMenuItem.Text = "Adherant"
        '
        'QuitterToolStripMenuItem
        '
        Me.QuitterToolStripMenuItem.Name = "QuitterToolStripMenuItem"
        Me.QuitterToolStripMenuItem.Size = New System.Drawing.Size(54, 20)
        Me.QuitterToolStripMenuItem.Text = "quitter"
        '
        'HomeToolStripMenuItem
        '
        Me.HomeToolStripMenuItem.Name = "HomeToolStripMenuItem"
        Me.HomeToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.HomeToolStripMenuItem.Text = "Home"
        '
        'AjoutEditionLivre
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(773, 546)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.BT_SAVE)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.nte)
        Me.Controls.Add(Me.Mais)
        Me.Controls.Add(Me.gnr2)
        Me.Controls.Add(Me.gnre1)
        Me.Controls.Add(Me.auteurr)
        Me.Controls.Add(Me.dt_srt)
        Me.Controls.Add(Me.nom)
        Me.Controls.Add(Me.label15)
        Me.Controls.Add(Me.avis)
        Me.Controls.Add(Me.coll)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.collection)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.IMG_AFFICHE)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "AjoutEditionLivre"
        Me.Text = "AjoutEditionLivre"
        CType(Me.nte, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.IMG_AFFICHE, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BT_SAVE As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents nte As System.Windows.Forms.NumericUpDown
    Friend WithEvents Mais As System.Windows.Forms.TextBox
    Friend WithEvents gnr2 As System.Windows.Forms.ComboBox
    Friend WithEvents gnre1 As System.Windows.Forms.ComboBox
    Friend WithEvents auteurr As System.Windows.Forms.ComboBox
    Friend WithEvents dt_srt As System.Windows.Forms.DateTimePicker
    Friend WithEvents nom As System.Windows.Forms.TextBox
    Friend WithEvents label15 As System.Windows.Forms.Label
    Friend WithEvents avis As System.Windows.Forms.TextBox
    Friend WithEvents coll As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents collection As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents IMG_AFFICHE As System.Windows.Forms.PictureBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents EditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LivresToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AdherantToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QuitterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HomeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
