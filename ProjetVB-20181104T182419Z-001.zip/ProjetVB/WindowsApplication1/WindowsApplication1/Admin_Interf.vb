﻿Public Class Admin_Interf

    Private Sub QuitterToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QuitterToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub LivresToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LivresToolStripMenuItem.Click
        ListeLivres.Show()
        Me.Hide()
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        ListeLivres.Show()
        Me.Hide()

    End Sub


    Private Sub Admin_Interf_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class