﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ListeLivres
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ListeLivres))
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.supprime = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.createe = New System.Windows.Forms.Button()
        Me.nte = New System.Windows.Forms.Label()
        Me.label15 = New System.Windows.Forms.Label()
        Me.thoughts = New System.Windows.Forms.TextBox()
        Me.collect = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.edit = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.gr = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.gnre = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.atr = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.dte = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.titr = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.modif = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.auteur = New System.Windows.Forms.ComboBox()
        Me.titre = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.effacee = New System.Windows.Forms.Button()
        Me.rcherche = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.liste_livree = New System.Windows.Forms.ListBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.HomeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LivresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdherantToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QuitterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Wheat
        Me.GroupBox3.Controls.Add(Me.supprime)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.createe)
        Me.GroupBox3.Controls.Add(Me.nte)
        Me.GroupBox3.Controls.Add(Me.label15)
        Me.GroupBox3.Controls.Add(Me.thoughts)
        Me.GroupBox3.Controls.Add(Me.collect)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.edit)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.gr)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.gnre)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.atr)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.dte)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.titr)
        Me.GroupBox3.Controls.Add(Me.PictureBox1)
        Me.GroupBox3.Controls.Add(Me.modif)
        Me.GroupBox3.Location = New System.Drawing.Point(288, 39)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(444, 579)
        Me.GroupBox3.TabIndex = 5
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Fiche détaillée"
        '
        'supprime
        '
        Me.supprime.Location = New System.Drawing.Point(9, 510)
        Me.supprime.Name = "supprime"
        Me.supprime.Size = New System.Drawing.Size(127, 23)
        Me.supprime.TabIndex = 50
        Me.supprime.Text = "Supprimer cette fiche"
        Me.supprime.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(142, 469)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(24, 13)
        Me.Label5.TabIndex = 49
        Me.Label5.Text = "/20"
        '
        'createe
        '
        Me.createe.Location = New System.Drawing.Point(156, 510)
        Me.createe.Name = "createe"
        Me.createe.Size = New System.Drawing.Size(143, 23)
        Me.createe.TabIndex = 22
        Me.createe.Text = "Créer une nouvelle fiche"
        Me.createe.UseVisualStyleBackColor = True
        '
        'nte
        '
        Me.nte.Location = New System.Drawing.Point(109, 468)
        Me.nte.Name = "nte"
        Me.nte.Size = New System.Drawing.Size(27, 14)
        Me.nte.TabIndex = 21
        Me.nte.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'label15
        '
        Me.label15.AutoSize = True
        Me.label15.Location = New System.Drawing.Point(6, 443)
        Me.label15.Name = "label15"
        Me.label15.Size = New System.Drawing.Size(93, 13)
        Me.label15.TabIndex = 20
        Me.label15.Text = "Note personnelle :"
        '
        'thoughts
        '
        Me.thoughts.Enabled = False
        Me.thoughts.Location = New System.Drawing.Point(6, 368)
        Me.thoughts.Multiline = True
        Me.thoughts.Name = "thoughts"
        Me.thoughts.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.thoughts.Size = New System.Drawing.Size(413, 63)
        Me.thoughts.TabIndex = 19
        '
        'collect
        '
        Me.collect.Enabled = False
        Me.collect.Location = New System.Drawing.Point(6, 255)
        Me.collect.Multiline = True
        Me.collect.Name = "collect"
        Me.collect.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.collect.Size = New System.Drawing.Size(413, 84)
        Me.collect.TabIndex = 18
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(3, 352)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(82, 13)
        Me.Label16.TabIndex = 16
        Me.Label16.Text = "Avis personnel :"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(6, 239)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(128, 13)
        Me.Label14.TabIndex = 14
        Me.Label14.Text = "Dans la meme collection :"
        '
        'edit
        '
        Me.edit.Location = New System.Drawing.Point(269, 181)
        Me.edit.Name = "edit"
        Me.edit.Size = New System.Drawing.Size(150, 50)
        Me.edit.TabIndex = 13
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(180, 181)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(70, 13)
        Me.Label13.TabIndex = 12
        Me.Label13.Text = "Maison d'ed :"
        '
        'gr
        '
        Me.gr.Location = New System.Drawing.Point(269, 155)
        Me.gr.Name = "gr"
        Me.gr.Size = New System.Drawing.Size(150, 13)
        Me.gr.TabIndex = 11
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(180, 155)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(51, 13)
        Me.Label12.TabIndex = 10
        Me.Label12.Text = "Genre 2 :"
        '
        'gnre
        '
        Me.gnre.Location = New System.Drawing.Point(269, 128)
        Me.gnre.Name = "gnre"
        Me.gnre.Size = New System.Drawing.Size(150, 17)
        Me.gnre.TabIndex = 9
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(180, 128)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(51, 13)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "Genre 1 :"
        '
        'atr
        '
        Me.atr.Location = New System.Drawing.Point(269, 100)
        Me.atr.Name = "atr"
        Me.atr.Size = New System.Drawing.Size(150, 13)
        Me.atr.TabIndex = 7
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(180, 100)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(50, 13)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "Auteur   :"
        '
        'dte
        '
        Me.dte.Location = New System.Drawing.Point(269, 73)
        Me.dte.Name = "dte"
        Me.dte.Size = New System.Drawing.Size(150, 17)
        Me.dte.TabIndex = 5
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(180, 73)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(79, 13)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Date de sortie :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(173, 73)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(0, 13)
        Me.Label6.TabIndex = 3
        '
        'titr
        '
        Me.titr.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.titr.Location = New System.Drawing.Point(172, 21)
        Me.titr.Name = "titr"
        Me.titr.Size = New System.Drawing.Size(247, 39)
        Me.titr.TabIndex = 2
        Me.titr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.ErrorImage = CType(resources.GetObject("PictureBox1.ErrorImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(6, 18)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(160, 213)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'modif
        '
        Me.modif.Location = New System.Drawing.Point(305, 510)
        Me.modif.Name = "modif"
        Me.modif.Size = New System.Drawing.Size(114, 23)
        Me.modif.TabIndex = 0
        Me.modif.Text = "Modifier cette fiche"
        Me.modif.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Wheat
        Me.GroupBox2.Controls.Add(Me.auteur)
        Me.GroupBox2.Controls.Add(Me.titre)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.effacee)
        Me.GroupBox2.Controls.Add(Me.rcherche)
        Me.GroupBox2.Location = New System.Drawing.Point(38, 39)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(244, 231)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Recherche"
        '
        'auteur
        '
        Me.auteur.FormattingEnabled = True
        Me.auteur.Location = New System.Drawing.Point(61, 128)
        Me.auteur.Name = "auteur"
        Me.auteur.Size = New System.Drawing.Size(167, 21)
        Me.auteur.TabIndex = 10
        '
        'titre
        '
        Me.titre.Location = New System.Drawing.Point(61, 66)
        Me.titre.Name = "titre"
        Me.titre.Size = New System.Drawing.Size(167, 20)
        Me.titre.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 117)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Auteur :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 47)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Titre : "
        '
        'effacee
        '
        Me.effacee.Location = New System.Drawing.Point(6, 181)
        Me.effacee.Name = "effacee"
        Me.effacee.Size = New System.Drawing.Size(102, 23)
        Me.effacee.TabIndex = 1
        Me.effacee.Text = "Effacer les critères"
        Me.effacee.UseVisualStyleBackColor = True
        '
        'rcherche
        '
        Me.rcherche.Location = New System.Drawing.Point(135, 181)
        Me.rcherche.Name = "rcherche"
        Me.rcherche.Size = New System.Drawing.Size(103, 23)
        Me.rcherche.TabIndex = 0
        Me.rcherche.Text = "Recherche"
        Me.rcherche.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Wheat
        Me.GroupBox1.Controls.Add(Me.liste_livree)
        Me.GroupBox1.Location = New System.Drawing.Point(38, 278)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(244, 342)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Liste des livres"
        '
        'liste_livree
        '
        Me.liste_livree.FormattingEnabled = True
        Me.liste_livree.Items.AddRange(New Object() {"Black Rose", "admin"})
        Me.liste_livree.Location = New System.Drawing.Point(9, 19)
        Me.liste_livree.Name = "liste_livree"
        Me.liste_livree.Size = New System.Drawing.Size(229, 290)
        Me.liste_livree.TabIndex = 0
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HomeToolStripMenuItem, Me.EditToolStripMenuItem, Me.QuitterToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(755, 24)
        Me.MenuStrip1.TabIndex = 6
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'HomeToolStripMenuItem
        '
        Me.HomeToolStripMenuItem.Name = "HomeToolStripMenuItem"
        Me.HomeToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.HomeToolStripMenuItem.Text = "Home"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LivresToolStripMenuItem, Me.AdherantToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(49, 20)
        Me.EditToolStripMenuItem.Text = "Editer"
        '
        'LivresToolStripMenuItem
        '
        Me.LivresToolStripMenuItem.Name = "LivresToolStripMenuItem"
        Me.LivresToolStripMenuItem.Size = New System.Drawing.Size(123, 22)
        Me.LivresToolStripMenuItem.Text = " Livres"
        '
        'AdherantToolStripMenuItem
        '
        Me.AdherantToolStripMenuItem.Name = "AdherantToolStripMenuItem"
        Me.AdherantToolStripMenuItem.Size = New System.Drawing.Size(123, 22)
        Me.AdherantToolStripMenuItem.Text = "Adherant"
        '
        'QuitterToolStripMenuItem
        '
        Me.QuitterToolStripMenuItem.Name = "QuitterToolStripMenuItem"
        Me.QuitterToolStripMenuItem.Size = New System.Drawing.Size(54, 20)
        Me.QuitterToolStripMenuItem.Text = "quitter"
        '
        'ListeLivres
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(755, 630)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "ListeLivres"
        Me.Text = "ListeLivres"
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents supprime As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents createe As System.Windows.Forms.Button
    Friend WithEvents nte As System.Windows.Forms.Label
    Friend WithEvents label15 As System.Windows.Forms.Label
    Friend WithEvents thoughts As System.Windows.Forms.TextBox
    Friend WithEvents collect As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents edit As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents gr As System.Windows.Forms.Label
    Friend WithEvents gnre As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents atr As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents dte As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents titr As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents modif As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents auteur As System.Windows.Forms.ComboBox
    Friend WithEvents titre As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents effacee As System.Windows.Forms.Button
    Friend WithEvents rcherche As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents liste_livree As System.Windows.Forms.ListBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents EditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LivresToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AdherantToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QuitterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HomeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
