﻿Imports System.Data.SqlClient
Public Class Form2

    Dim connection As New SqlConnection("Server= (local); Database = TestDB; Integrated Security = true")


    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FilterData("")

    End Sub

    Public Sub FilterData(ByVal valueToSearch As String)

        Dim searchQuery As String = "SELECT * From Livre WHERE ( nom) like '%" & valueToSearch & "%' or ( code) like '%" & valueToSearch & "%' or ( auteur ) like '%" & valueToSearch & "%' or ( categorie ) like '%" & valueToSearch & "%'"
        Dim command As New SqlCommand(searchQuery, connection)
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable()

        adapter.Fill(table)

        DataGridView1.DataSource = table

    End Sub


    Private Sub BTN_FILTER_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTN_FILTER.Click
        FilterData(TextBox1.Text)
    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim Rep As Integer

        Rep = MsgBox("Voulez-vous deconnecter ?", vbYesNo + vbQuestion, "Deconnection")
        If Rep = vbYes Then
            MsgBox("adios")
            Form1.pass.Text = ""
            Form1.nom.Text = ""
            Me.Close()
            Form5.Close()
            Form1.Show()


        End If


    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        form4.Show()

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Hide()
        Form5.Show()
    End Sub


End Class