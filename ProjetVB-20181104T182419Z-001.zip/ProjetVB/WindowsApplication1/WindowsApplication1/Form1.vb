﻿Imports System.Data.SqlClient

Public Class Form1


    Private Sub connecter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles connecter.Click


        Dim connection As New SqlConnection("Server= (local); Database = TestDB; Integrated Security = true")

        Dim command As New SqlCommand("select * from Table_Login where Username = @username and Password = @password", connection)

        command.Parameters.Add("@username", SqlDbType.VarChar).Value = nom.Text
        command.Parameters.Add("@password", SqlDbType.VarChar).Value = pass.Text

        Dim adapter As New SqlDataAdapter(command)

        Dim table As New DataTable()

        adapter.Fill(table)

        If table.Rows.Count() <= 0 Then

            MessageBox.Show("Username Or Password Are Invalid")

        ElseIf nom.Text = "admin" And pass.Text = "admin" Then
                MessageBox.Show("Login Successfully")

            Admin_Interf.Show()

            Me.Hide()
        Else

            Me.Hide()

            Form2.Show()

            End If


    End Sub



    Private Sub annuler_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles annuler.Click
        Dim Rep As Integer

        Rep = MsgBox("Voulez-vous quitter ?", vbYesNo + vbQuestion, "QUITTER")
        If Rep = vbYes Then
            Me.Close()
        End If

    End Sub


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

   


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Hide()
        Form3.Show()

    End Sub
End Class
