﻿Imports System.Data.SqlClient

Public Class AjoutEditionLivre

    Dim conn As New SqlConnection("Data Source=hp-PC; Database = TestDB; Integrated Security = true")

    Private Sub BT_SAVE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BT_SAVE.Click
        If (Me.auteurr.Text = "") Then

            MessageBox.Show("verifier votre auteur")
        ElseIf (Me.nom.Text = "") Then
            MessageBox.Show("verifier le nom du livre")

        Else
            Try


                Dim insertQuery As String = "insert into Livre values('" & Me.auteurr.Text & "','" & Me.avis.Text & "','" & Me.nom.Text & "','" & Me.gnre1.Text & "','" & Me.gnr2.Text & "','" & Me.nte.Text & "','" & Me.dt_srt.Value.ToString() & "','" & Me.coll.Text & "','" & Me.Mais.Text & "')"
                ExecuteQuery(insertQuery)

                MessageBox.Show("Fiche correctement crée")

            Catch ex As Exception
                MsgBox("err requete")

            End Try
        End If
        Me.Close()
        ListeLivres.Show()
    End Sub
    Public Sub ExecuteQuery(ByVal query As String)

        Dim command As New SqlCommand(query, conn)

        conn.Open()

        command.ExecuteNonQuery()

        conn.Close()

    End Sub


    Private Sub AjoutEditionLivre_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub LivresToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LivresToolStripMenuItem.Click
        ListeLivres.Show()
        Me.Close()

    End Sub

    Private Sub HomeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HomeToolStripMenuItem.Click
        Admin_Interf.Show()

    End Sub
End Class