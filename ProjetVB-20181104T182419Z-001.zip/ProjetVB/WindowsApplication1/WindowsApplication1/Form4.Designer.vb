﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(form4))
        Me.dateRetour = New System.Windows.Forms.DateTimePicker()
        Me.dateEmp = New System.Windows.Forms.DateTimePicker()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.titre = New System.Windows.Forms.TextBox()
        Me.ans = New System.Windows.Forms.TextBox()
        Me.categ = New System.Windows.Forms.TextBox()
        Me.auteur = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.anul = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.idl = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Code = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'dateRetour
        '
        Me.dateRetour.Location = New System.Drawing.Point(240, 471)
        Me.dateRetour.Name = "dateRetour"
        Me.dateRetour.Size = New System.Drawing.Size(161, 20)
        Me.dateRetour.TabIndex = 35
        '
        'dateEmp
        '
        Me.dateEmp.Location = New System.Drawing.Point(253, 403)
        Me.dateEmp.Name = "dateEmp"
        Me.dateEmp.Size = New System.Drawing.Size(161, 20)
        Me.dateEmp.TabIndex = 34
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Wheat
        Me.Label7.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(66, 403)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(117, 27)
        Me.Label7.TabIndex = 33
        Me.Label7.Text = "date Emp"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Wheat
        Me.Label1.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(66, 471)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(117, 27)
        Me.Label1.TabIndex = 32
        Me.Label1.Text = "date Retour"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'titre
        '
        Me.titre.Location = New System.Drawing.Point(250, 136)
        Me.titre.Name = "titre"
        Me.titre.Size = New System.Drawing.Size(164, 20)
        Me.titre.TabIndex = 31
        '
        'ans
        '
        Me.ans.Location = New System.Drawing.Point(250, 343)
        Me.ans.Name = "ans"
        Me.ans.Size = New System.Drawing.Size(164, 20)
        Me.ans.TabIndex = 30
        '
        'categ
        '
        Me.categ.Location = New System.Drawing.Point(250, 273)
        Me.categ.Name = "categ"
        Me.categ.Size = New System.Drawing.Size(164, 20)
        Me.categ.TabIndex = 29
        '
        'auteur
        '
        Me.auteur.Location = New System.Drawing.Point(253, 204)
        Me.auteur.Name = "auteur"
        Me.auteur.Size = New System.Drawing.Size(164, 20)
        Me.auteur.TabIndex = 28
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Wheat
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(396, 522)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(95, 45)
        Me.Button1.TabIndex = 27
        Me.Button1.Text = "Ok"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'anul
        '
        Me.anul.BackColor = System.Drawing.Color.Wheat
        Me.anul.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.anul.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.anul.Location = New System.Drawing.Point(522, 522)
        Me.anul.Name = "anul"
        Me.anul.Size = New System.Drawing.Size(98, 45)
        Me.anul.TabIndex = 26
        Me.anul.Text = "Annuler"
        Me.anul.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Wheat
        Me.Label6.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(66, 337)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(117, 27)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "Anneé"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Wheat
        Me.Label5.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(66, 267)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(117, 27)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "categorie"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Wheat
        Me.Label3.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(66, 197)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(117, 27)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "Auteur "
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Wheat
        Me.Label2.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(66, 136)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(117, 27)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Titre "
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'idl
        '
        Me.idl.Location = New System.Drawing.Point(250, 27)
        Me.idl.Name = "idl"
        Me.idl.Size = New System.Drawing.Size(164, 20)
        Me.idl.TabIndex = 39
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Wheat
        Me.Label8.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(66, 27)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(117, 27)
        Me.Label8.TabIndex = 38
        Me.Label8.Text = "Votre id "
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Code
        '
        Me.Code.Location = New System.Drawing.Point(250, 79)
        Me.Code.Name = "Code"
        Me.Code.Size = New System.Drawing.Size(164, 20)
        Me.Code.TabIndex = 37
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Wheat
        Me.Label4.Font = New System.Drawing.Font("Rockwell", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(66, 79)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(117, 27)
        Me.Label4.TabIndex = 36
        Me.Label4.Text = "CodeLivre"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(621, 590)
        Me.Controls.Add(Me.idl)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Code)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.dateRetour)
        Me.Controls.Add(Me.dateEmp)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.titre)
        Me.Controls.Add(Me.ans)
        Me.Controls.Add(Me.categ)
        Me.Controls.Add(Me.auteur)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.anul)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "form4"
        Me.Text = "LV"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dateRetour As System.Windows.Forms.DateTimePicker
    Friend WithEvents dateEmp As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents titre As System.Windows.Forms.TextBox
    Friend WithEvents ans As System.Windows.Forms.TextBox
    Friend WithEvents categ As System.Windows.Forms.TextBox
    Friend WithEvents auteur As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents anul As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents idl As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Code As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class
